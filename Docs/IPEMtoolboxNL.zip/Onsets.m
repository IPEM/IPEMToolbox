%To extract the onsets from Schumann�s Kuriose Geschichte , use the following expression:
[Ts,Tsmp] = IPEMDoOnsets('SchumannKurioseGeschichte.wav');

%You can of course split the module in the several subparts. For example, if you first process the
%file with the Auditory Peripheral Module, and then apply the onsets module, you could use:
[ANI,ANIFreq,ANIFilterFreqs] = IPEMCalcANIFromFile('SchumannKurioseGeschichte.wav');
[OnsetSignal,OnsetFreq] = IPEMCalcOnsetsFromANI(ANI,ANIFreq);