[s1,fs] = IPEMReadSoundFile('SchumannKurioseGeschichte.wav');
s2 = zeros(1,round(0.1*fs));
NoteFreq = IPEMCalcNoteFrequency('F#4');
s3 = IPEMShepardTone(NoteFreq,0.5,fs,1,-20);
s = [s1 s2 s3];
[ANI,ANIFreq,ANIFilterFreqs] = IPEMCalcANI(s,fs);
[PP,PPFreq,PPPeriods,PPFANI] = IPEMPeriodicityPitch(ANI,ANIFreq,[],[],[],1);
[Chords,ToneCenters,LocalInspection,GlobalInspection,LocalGlobalComparison] = ...
IPEMContextualityIndex(PP,PPFreq,PPPeriods,[],0.1,1.5,[],1);