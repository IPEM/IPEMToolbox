%Echoic Memory Module can be applied to a pitch completion image to obtain a local and a
%global pitch image.
[ANI,ANIFreq,ANIFilterFreqs] = IPEMCalcANIFromFile('SchumannKurioseGeschichte.wav');
[PP,PPFreq,PPPeriods,PPFANI] = IPEMPeriodicityPitch(ANI,ANIFreq);
LocalIntegration = IPEMLeakyIntegration(PP,PPFreq,0.1,0.1,1);
GlobalIntegration = IPEMLeakyIntegration(PP,PPFreq,1.5,1.5,1);