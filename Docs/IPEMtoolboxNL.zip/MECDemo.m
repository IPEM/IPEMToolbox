% Read sound file
[s,fs]= IPEMReadSoundFile('photek.wav');
%[s,fs]= IPEMReadSoundFile('Tom Waits - Big In Japan.wav',[],[0 30]);

% Calculate energy signal (RMS)
[RMS,RMSFreq] = IPEMCalcRMS(s,fs,0.040,0.020,1);

% Analyse with MEC
[Periods,BestPeriodIndices,MECFreq,MECValues] = IPEMMECAnalysis(RMS,RMSFreq,0.5,4,1/RMSFreq,1.5,1);

% Animate difference values
N = size(BestPeriodIndices,2);
T = (0:N-1)/MECFreq;
figure;
Min = min(min(MECValues{1}));
Max = max(max(MECValues{1}));
H = plot(Periods,MECValues{1}(:,1));
set(H,'EraseMode','background');
xlabel('Period (s)');
ylabel('Difference value');
axis([Periods(1) Periods(end) Min Max]);
HTitle = title('');
for i = 1:N
    set(H,'YData',MECValues{1}(:,i));
    set(HTitle,'String',sprintf('Time = %.3f s',i/MECFreq));
    drawnow;
end

% IPEMDemoMECRhythmExtraction
