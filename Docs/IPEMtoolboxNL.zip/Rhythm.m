[ANI,ANIFreq,ANIFilterFreqs] = IPEMCalcANIFromFile('SchumannKurioseGeschichte.wav');
[RMS,RMSFreq] = IPEMCalcRMS(ANI,ANIFreq,0.05,0.005);
[Periods,Best,AnalysisFreq,Values] = IPEMMECAnalysis(RMS,RMSFreq,0.25,1,0.050,1.5);
SummaryPeriodicity = zeros(size(Values { 1 } ));
for channel = 1:40;
SummaryPeriodicity = SummaryPeriodicity + Values { channel } ;
end
figure;
imagesc((0:size(SummaryPeriodicity,2)-1)/AnalysisFreq,Periods,SummaryPeriodicity);
xlabel('Time (in s)'); ylabel('Period (in s)');
axis xy; colormap(1-gray);
[M,I]=min(SummaryPeriodicity); hold on;
plot((0:length(I)-1)/AnalysisFreq,Periods(I));